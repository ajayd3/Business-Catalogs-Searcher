# Business-Catalogs-Searcher

This project is attempting to create a dynamic website in which businesses are able to place their catalogue and customers are able to log in and browse a given business' catalogue. This project heavily features the Google Maps API, allowing customers to find their targeted businesses through Google Maps. Accounts are stored in a custom made database. HTML, CSS, and JavaScript are used to enhance the UI and to communicate with the database and Google Maps.
